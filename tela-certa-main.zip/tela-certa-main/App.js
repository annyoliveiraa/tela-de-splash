// SplashScreen.js

import React, { useEffect } from 'react';
import { View, Image, StyleSheet } from 'react-native';

const SplashScreen = ({ navigation }) => {
  useEffect(() => {
    // Simule um tempo de exibição da splash screen (por exemplo, 3 segundos)
    setTimeout(() => {
      navigation.navigate('Home'); // Navegue para a próxima tela após o tempo definido
    }, 3000);
  }, []);

  return (
    <View style={styles.container}>
      <Image source={require('./assets/splash.png')} style={styles.logo} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff', // Cor de fundo da splash screen
  },
  logo: {
    width: 800,
    height: 800,
    resizeMode: 'contain',
  },
});

export default SplashScreen;